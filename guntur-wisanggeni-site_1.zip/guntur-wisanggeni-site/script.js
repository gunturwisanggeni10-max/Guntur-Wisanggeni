(()=>{
 const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('vis');io.unobserve(e.target)}}),{threshold:.2});
 document.querySelectorAll('.rv').forEach(el=>io.observe(el));
 if(matchMedia('(hover:hover) and (prefers-reduced-motion:no-preference)').matches){
  const h=document.querySelector('.hero');
  h.addEventListener('mousemove',e=>{h.style.setProperty('--px',((e.clientX/innerWidth-.5)*-16).toFixed(1));h.style.setProperty('--py',((e.clientY/innerHeight-.5)*-10).toFixed(1))});
  h.addEventListener('mouseleave',()=>{h.style.setProperty('--px',0);h.style.setProperty('--py',0)});
 }
})();
