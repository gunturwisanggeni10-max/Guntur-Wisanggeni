# Guntur Wisanggeni — Personal Landing Page
Static site (HTML/CSS/JS, tanpa build) — siap GitHub Pages.

## Publikasi
1. Upload semua isi folder ini ke repo GitHub (branch `main`).
2. Settings → Pages → Source: **GitHub Actions** (atau "Deploy from a branch" → `main` / root).
3. Ganti `https://YOUR-USERNAME.github.io/YOUR-REPO/` di `index.html` (canonical, og:url, og:image, JSON-LD) dengan URL final situs.

## Struktur
`index.html` · `style.css` · `script.js` · `assets/img/` (portrait .webp, og-image.jpg) · favicon.*
Ikon Kompasiana berupa monogram sederhana; ganti dengan logo resmi jika ada (`<symbol id="kp">`).
